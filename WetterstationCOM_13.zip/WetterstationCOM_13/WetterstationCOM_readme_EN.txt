-----------------------------------------------------------------------------
Program for reading the data of different weather stations via the serial interface of a computer.
-----------------------------------------------------------------------------

Suitable for weather stations:

- 30152 P04/3-RS485-GPS
- 30153 P04/3-RS485-CET
- 30154 P04/3-RS485 basic
- 30145 P03/3-RS485-GPS
- 30151 P03/3-RS485-CET
- 30140 P03/3-RS485 basic
- 30146 P03/3-Modbus
- 30147 P03/3-Modbus-GPS
- Animeo IB-Compact Sensor

A converter (adapter) is required for connection to the PC. Tested converters:
- ExSys EX-1309-T 
- Digitus DA-70157 (not for Animeo IB-Compact Sensor)

-----------------------------------------------------------------------------
-----------------------------------------------------------------------------

WetterstationCOM help:

The file "WetterstationCOM.exe" and the folder "en" must be in the same directory.

1. Select port:
--------------------------
The port settings can be changed in the menu item "Settings -> Port". After start-up, the port to which the weather station is connected should be selected manually.  
By default the program selects the first available COM port.

2. Select model:
--------------------------
Select the weather station model from the Weather Station pull-down menu. This will prepare the serial port for communication with the weather station.
The port configuration is displayed in the status bar (at the bottom of the window). 

3. Connect:
--------------------------
Click on "Connect" to establish the communication connection to the weather station. Data can now be sent and received.

4. Display of the data:
--------------------------
Received weather station data are output as ASCII characters in the large text field on the left of the window. One line corresponds to one received data frame.
If the frame has been received correctly, the weather data fields on the right side are filled with the corresponding data.

Above the text field there is another output field. Here a single frame can be displayed either in ASCII format, hexadecimal or decimal. 
The latest received frame is selected automatically and represented in the upper, small field. To select another frame, click on the corresponding line in the large text field. 
The weather data fields are updated according to the selection.

Click "Clear" to clear all frames in the text box. This can be helpful, for example, if selecting a line in the text field causes difficulties. 

5. Send request:
--------------------------
The weather station models P03/3-Modbus, P03-Modbus-GPS and Animeo IB deliver data only on request. Select a request from the pull-down menu "Send Frame". 
The selected request frame is displayed in the output field on the left.

Click on "Send" to send the request to the weather station.

If the checkbox "Send automatically" is checked, the selected request frame will be sent periodically. The transmission cycle is set below the button.

6. Disconnect:
--------------------------
To disconnect, click "Disconnect" while a connection is established.

7. Additional options and notes:
--------------------------
The status bar (at the bottom of the window) displays current information or warnings.

The program is only suitable for reading frame-based data. For reading a constant data stream, other terminal programs have to be used.